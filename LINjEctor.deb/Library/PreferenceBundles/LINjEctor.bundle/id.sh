#!/bin/sh
killall LINE
cd /var/mobile/Applications/*/LINE.app/../Documents
sqlite3 talk.sqlite "delete from ZGROUP where ZISACCEPTED=0;"
