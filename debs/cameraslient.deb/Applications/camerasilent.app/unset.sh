#!/bin/sh
mv /System/Library/Audio/UISounds/photoShutter.caf.bk /System/Library/Audio/UISounds/photoShutter.caf