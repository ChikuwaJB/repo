#!/bin/sh
mv /System/Library/Audio/UISounds/photoShutter.caf /System/Library/Audio/UISounds/photoShutter.caf.bk

mv /System/Library/Audio/UISounds/begin_record.caf /System/Library/Audio/UISounds/begin_record.caf.bk
cp /Applications/camerasilent.app/silent.caf /System/Library/Audio/UISounds/begin_record.caf

mv /System/Library/Audio/UISounds/end_record.caf /System/Library/Audio/UISounds/end_record.caf.bk
cp /Applications/camerasilent.app/silent.caf /System/Library/Audio/UISounds/end_record.caf