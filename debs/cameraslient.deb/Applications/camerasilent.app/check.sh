#!/bin/sh

if [ -e /System/Library/Audio/UISounds/photoShutter.caf ]; then
echo -n no > /var/mobile/aaaaaaaa
else
echo -n ok > /var/mobile/aaaaaaaa
fi

