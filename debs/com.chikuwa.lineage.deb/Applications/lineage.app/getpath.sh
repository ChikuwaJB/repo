#!/bin/sh
cd /var/mobile/Applications/*/LINE.app/
cd ../Library/Preferences/
tt=`pwd`
echo "${tt}/jp.naver.line.plist" > /var/mobile/path