#!/bin/sh

tt=`pwd`
find /var/mobile/Containers/Data/Application/*/ -name jp.naver.line.plist > /var/mobile/path
echo "${tt}/jp.naver.line.plist"
