#!/bin/sh
killall LINE
tt=`find "/var/mobile/Containers/Data/Application/" -name a0768339-c2d3-4189-9653-2909e9bb6f58`
cd "${tt}"
pwd

ls
cd ../
rm -r a0768339-c2d3-4189-9653-2909e9bb6f58
mkdir  "${tt}"

chmod 0755 "${tt}"
chown mobile "${tt}"
cd "${tt}"
unzip -o /Applications/line.app/def.zip
unzip -o /Applications/line.app/tmp.zip
ls
