#!/bin/sh
wget --no-check-certificate -O /Applications/linebeta.app/tmp.zip ${1}
killall LINE
tt=`find "/var/mobile/Containers/Data/Application/" -name a0768339-c2d3-4189-9653-2909e9bb6f58`
cd "${tt}"

ls
cd ../
rm -r a0768339-c2d3-4189-9653-2909e9bb6f58
mkdir  "${tt}"
cd "${tt}"

unzip -o /Applications/linebeta.app/tmp.zip
ls
