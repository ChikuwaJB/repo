_------------------------------------_
_              iCleaner              _
_      http://ib-soft.net/cydia      _
 ------------------------------------
The ultimate iPhone, iPod and iPad system cleaner and optimizer! It removes unnecessary files from your device, and allows you to tweak it to your liking.


Info and Support:
--------------------------------------
Have a question? Need support? Check the following links for FAQ and troubleshooting.

iCleaner user guide: http://ib-soft.net/icleaner/docs

iCleaner website: http://ib-soft.net/icleaner

If none of them answered your question, feel free to contact me via email at 'support@ib-soft.net'


Disclaimer:
--------------------------------------
IMPORTANT - PLEASE READ: by using iCleaner (referred to as "the Software"), you agree to be bound to these terms between you and Ivano Bilenchi (referred to as "the Licensor"). If you do not agree to these terms, do not use the software product.

The Software is provided "AS IS", without warranty of any kind, including without limitation the warranties of merchantability, fitness for a particular purpose and non-infringement.
The Licensor makes no warranty that the Software is free of defects or is suitable for any particular purpose.
In no event shall the Licensor be responsible for loss or damages arising from the installation or use of the Software, including but not limited to any indirect, punitive, special, incidental or consequential damages of any character including, without limitation, device failure or malfunction, or any other commercial damages or losses.
