#!/bin/sh
killall LINE
cd /var/mobile/Applications/*/LINE.app/
cd ../
cd "Library/Application Support/Theme Packages"
cd a0768339-c2d3-4189-9653-2909e9bb6f58
unzip -o /Applications/line.app/tmp.zip
ls
rm /Applications/line.app/tmp.zip