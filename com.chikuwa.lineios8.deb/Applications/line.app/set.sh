#!/bin/sh
killall LINE
tt=`find "/var/mobile/Containers/Data/Application/" -type d -name images | grep a0768339-c2d3-4189-9653-2909e9bb6f58`
cd "${tt}"
cd ../
unzip -o /Applications/line.app/tmp.zip
ls
